
import { GoogleGenAI, Type } from "@google/genai";
import { AnalysisResult, AnalysisType, FeedbackReport } from "../types";

export const submitFeedback = async (report: FeedbackReport): Promise<boolean> => {
  console.log("Data Accuracy Anomaly Reported:", report);
  return new Promise((resolve) => setTimeout(resolve, 1500));
};

export const analyzePhoneNumber = async (
  phoneNumber: string,
  context?: string
): Promise<AnalysisResult & { sources?: { title: string; uri: string }[] }> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const prompt = `Perform a high-level security audit on the phone number: ${phoneNumber}. 
  Context: ${context || "None"}.
  
  TASK:
  1. Determine if the number is AUTHENTIC (Safe) or MALICIOUS (Danger).
  2. Calculate the DATA ACCURACY (0-100%). This is your verification certainty of the status.
  3. Identify Region, Carrier, and Fraud Association.
  
  Return a JSON response. Use Google Search for real-time fraud reports.
  The 'confidence' field should be used for the 'Data Accuracy' percentage.`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: { parts: [{ text: prompt }] },
      config: {
        tools: [{ googleSearch: {} }],
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            score: { type: Type.NUMBER },
            confidence: { type: Type.NUMBER, description: "The calculated data accuracy percentage" },
            verdict: { type: Type.STRING, enum: ["SAFE", "SUSPICIOUS", "DANGEROUS"] },
            summary: { type: Type.STRING },
            details: { type: Type.ARRAY, items: { type: Type.STRING } },
            recommendations: { type: Type.ARRAY, items: { type: Type.STRING } }
          },
          required: ["score", "verdict", "summary", "details", "recommendations", "confidence"],
        },
      },
    });

    const result = JSON.parse(response.text?.trim() || "{}") as AnalysisResult;
    
    const sources = response.candidates?.[0]?.groundingMetadata?.groundingChunks?.map((chunk: any) => ({
      title: chunk.web?.title || "Web Reference",
      uri: chunk.web?.uri || "#"
    })).filter((s: any) => s.uri !== "#");

    return { ...result, sources };
  } catch (error) {
    console.error("Number Lookup Error:", error);
    throw new Error("Target search failed. Uplink unstable.");
  }
};

export const analyzeContent = async (
  content: string | Blob,
  type: AnalysisType,
  mimeType?: string
): Promise<AnalysisResult> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  let prompt = "";
  let contents: any;

  if (type === AnalysisType.MESSAGE) {
    prompt = `Audit this text for fraud. Calculate the DATA ACCURACY (verification certainty) of your verdict. 
    If DANGER: How accurate is your detection of the fraud pattern?
    If SAFE: How accurate is the verification of authenticity?`;
    contents = { parts: [{ text: `${prompt}\n\nCONTENT:\n${content as string}` }] };
  } else if (type === AnalysisType.QR) {
    prompt = `Audit this QR payload: "${content as string}". 
    Calculate the DATA ACCURACY of your security assessment. Check for phishing redirects and payment fraud patterns.`;
    contents = { parts: [{ text: prompt }] };
  } else if (type === AnalysisType.IMAGE) {
    prompt = `Perform a forensic audit on this image. 
    Detect if it is a deepfake, AI-generated, or manipulated. 
    Look for: lighting inconsistencies, edge artifacts, frequency domain anomalies, and blurred features.
    Calculate DATA ACCURACY (verification certainty). 
    SAFE = Real Photo, DANGER = Synthetic/Fake.`;
    
    const base64Data = await blobToBase64(content as Blob);
    contents = {
      parts: [
        { inlineData: { data: base64Data, mimeType: mimeType || 'image/jpeg' } },
        { text: prompt }
      ]
    };
  } else if (type === AnalysisType.VIDEO) {
    prompt = `Perform a forensic audit on this video snippet. 
    Detect if it is a deepfake or AI-manipulated video. 
    Look for: jittery movements, unnatural eye blinking, lip-sync mismatch, and facial inconsistencies.
    Calculate DATA ACCURACY (verification certainty). 
    SAFE = Real Video, DANGER = Synthetic/Fake.`;
    
    const base64Data = await blobToBase64(content as Blob);
    contents = {
      parts: [
        { inlineData: { data: base64Data, mimeType: mimeType || 'video/mp4' } },
        { text: prompt }
      ]
    };
  } else {
    // Audio analysis
    prompt = `Analyze this audio for deepfake markers. 
    Calculate the DATA ACCURACY percentage based on vocal artifacts, breathing patterns, and synthetic pauses. 
    Provide the accuracy of your detection of real vs synthetic speech.`;
    
    if (content instanceof Blob) {
      const base64Data = await blobToBase64(content);
      contents = {
        parts: [
          { inlineData: { data: base64Data, mimeType: mimeType || 'audio/wav' } },
          { text: prompt }
        ]
      };
    } else {
      contents = { parts: [{ text: `${prompt}\n(Context: ${content})` }] };
    }
  }

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            score: { type: Type.NUMBER },
            confidence: { type: Type.NUMBER, description: "Calculated Accuracy Percentage" },
            verdict: { type: Type.STRING, enum: ["SAFE", "SUSPICIOUS", "DANGEROUS"] },
            summary: { type: Type.STRING },
            details: { type: Type.ARRAY, items: { type: Type.STRING } },
            recommendations: { type: Type.ARRAY, items: { type: Type.STRING } }
          },
          required: ["score", "verdict", "summary", "details", "recommendations", "confidence"],
        },
      },
    });

    return JSON.parse(response.text?.trim() || "{}") as AnalysisResult;
  } catch (error) {
    console.error("Gemini Analysis Error:", error);
    throw new Error("Failed to analyze content. Please try again.");
  }
};

const blobToBase64 = (blob: Blob): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const base64String = (reader.result as string).split(',')[1];
      resolve(base64String);
    };
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
};
