
import React from 'react';
import { Shield, Mic, LayoutDashboard, Settings, Search, QrCode, Eye, Zap } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';
import HinglishChatbot from './HinglishChatbot';

const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const location = useLocation();

  const navItems = [
    { icon: LayoutDashboard, label: 'Home', path: '/' },
    { icon: Mic, label: 'Voice', path: '/voice' },
    { icon: Eye, label: 'Media', path: '/media' },
    { icon: Search, label: 'Lookup', path: '/lookup' },
    { icon: Shield, label: 'Guard', path: '/live' },
  ];

  return (
    <div className="min-h-screen bg-black flex flex-col max-w-md mx-auto border-x border-purple-900/20 shadow-[0_0_100px_rgba(168,85,247,0.1)] overflow-hidden relative">
      {/* Header */}
      <header className="bg-black/80 backdrop-blur-2xl text-white p-5 sticky top-0 z-50 border-b border-purple-500/10">
        <div className="flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2 group">
            <div className="bg-purple-600 p-2 rounded-xl shadow-[0_0_20px_rgba(168,85,247,0.4)] group-hover:scale-110 transition-transform">
              <Zap className="w-5 h-5 text-white fill-current" />
            </div>
            <h1 className="text-xl font-bold tracking-tighter text-white">SHIELD<span className="text-purple-500">X</span></h1>
          </Link>
          <Link 
            to="/settings" 
            className={`transition-all p-2 rounded-xl ${location.pathname === '/settings' ? 'text-purple-400 bg-purple-500/10 shadow-inner' : 'text-zinc-600 hover:text-purple-400'}`}
          >
            <Settings className="w-5 h-5" />
          </Link>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto pb-32 p-5 relative">
        {/* Ambient glow layers */}
        <div className="absolute top-20 right-[-100px] w-64 h-64 bg-purple-600/5 rounded-full blur-[100px] pointer-events-none"></div>
        <div className="absolute bottom-20 left-[-100px] w-64 h-64 bg-indigo-600/5 rounded-full blur-[100px] pointer-events-none"></div>
        
        {children}
      </main>

      {/* Assistant */}
      <HinglishChatbot />

      {/* Bottom Navigation */}
      <div className="fixed bottom-6 left-0 right-0 px-5 max-w-md mx-auto z-40">
        <nav className="bg-zinc-900/90 backdrop-blur-3xl border border-white/5 flex justify-around items-center h-20 rounded-[2.5rem] px-2 shadow-[0_20px_50px_rgba(0,0,0,0.5)]">
          {navItems.map((item) => {
            const isActive = location.pathname === item.path;
            return (
              <Link
                key={item.path}
                to={item.path}
                className={`flex flex-col items-center gap-1.5 transition-all duration-500 px-3 py-2 rounded-2xl ${
                  isActive ? 'text-purple-400 bg-purple-500/10' : 'text-zinc-500 hover:text-zinc-300'
                }`}
              >
                <item.icon className={`w-5 h-5 ${isActive ? 'drop-shadow-[0_0_12px_rgba(168,85,247,0.8)]' : ''}`} />
                <span className={`text-[9px] font-bold uppercase tracking-widest ${isActive ? 'opacity-100' : 'opacity-40'}`}>
                  {item.label}
                </span>
              </Link>
            );
          })}
        </nav>
      </div>
    </div>
  );
};

export default Layout;
