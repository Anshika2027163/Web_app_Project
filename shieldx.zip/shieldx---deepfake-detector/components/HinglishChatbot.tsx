
import React, { useState, useRef, useEffect } from 'react';
import { MessageSquare, X, Send, Loader2, ShieldQuestion, Sparkles, ChevronRight, Zap, Bot } from 'lucide-react';
import { GoogleGenAI, Chat, GenerateContentResponse } from "@google/genai";

const HinglishChatbot: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<{ role: 'user' | 'model'; text: string; id: string }[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  
  const scrollRef = useRef<HTMLDivElement>(null);
  const chatInstance = useRef<Chat | null>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isLoading]);

  const initChat = () => {
    if (!chatInstance.current) {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      chatInstance.current = ai.chats.create({
        model: 'gemini-3-flash-preview',
        config: {
          systemInstruction: `Aap ShieldX app ke digital safety assistant hain. Aapka naam 'Safety Guru' hai. Aap ek high-tech neural intelligence agent ki tarah behave karein.
          
          MISSION: Users ko online fraud, deepfakes, aur phishing se bachana.
          
          RULES:
          1. LANGUAGE: Sirf Hinglish (Hindi + English) use karein.
          2. STRUCTURE: Answers ko hamesha clean points (•) mein likhein.
          3. TONE: Professional, futuristic, high-tech aur helpful.`,
        },
      });
    }
  };

  const handleSend = async (customInput?: string) => {
    const textToProcess = customInput || input;
    if (!textToProcess.trim() || isLoading) return;
    
    initChat();
    
    const userMessageId = Math.random().toString(36).substring(7);
    setMessages(prev => [...prev, { role: 'user', text: textToProcess.trim(), id: userMessageId }]);
    setInput('');
    setIsLoading(true);

    try {
      let fullResponse = "";
      const streamResponse = await chatInstance.current!.sendMessageStream({ message: textToProcess.trim() });
      
      const modelMessageId = Math.random().toString(36).substring(7);
      setMessages(prev => [...prev, { role: 'model', text: '', id: modelMessageId }]);
      
      for await (const chunk of streamResponse) {
        const c = chunk as GenerateContentResponse;
        fullResponse += c.text;
        setMessages(prev => {
          const newMsgs = [...prev];
          const lastMsg = newMsgs[newMsgs.length - 1];
          if (lastMsg && lastMsg.role === 'model') {
            lastMsg.text = fullResponse;
          }
          return newMsgs;
        });
      }
    } catch (error) {
      console.error("Link Error:", error);
      setMessages(prev => [...prev, { 
        role: 'model', 
        text: "Neural Link communication error. Network stability check karein.", 
        id: 'err-' + Date.now() 
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed bottom-32 right-6 z-50 flex flex-col items-end pointer-events-none">
      {/* Chat Window */}
      {isOpen && (
        <div className="w-[380px] h-[600px] bg-black border border-white/5 rounded-[3.5rem] shadow-[0_40px_100px_rgba(0,0,0,0.9)] flex flex-col overflow-hidden mb-8 pointer-events-auto animate-in slide-up relative">
          <div className="absolute inset-0 bg-gradient-to-b from-purple-600/5 to-transparent pointer-events-none"></div>
          
          {/* Header */}
          <div className="p-7 bg-zinc-900/40 backdrop-blur-2xl border-b border-white/5 flex items-center justify-between relative z-10">
            <div className="flex items-center gap-5">
              <div className="w-14 h-14 bg-purple-600 rounded-[1.5rem] flex items-center justify-center shadow-[0_0_20px_rgba(168,85,247,0.4)] relative overflow-hidden group">
                <Bot className="w-8 h-8 text-white z-10" />
                <div className="absolute inset-0 bg-white/20 animate-pulse"></div>
              </div>
              <div>
                <h3 className="text-sm font-black text-white uppercase tracking-tighter italic">Safety Guru</h3>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                  <p className="text-[9px] text-zinc-500 font-black uppercase tracking-[0.2em]">Neural link Established</p>
                </div>
              </div>
            </div>
            
            <button 
              onClick={() => setIsOpen(false)} 
              className="w-12 h-12 bg-white/5 rounded-2xl text-zinc-500 hover:text-purple-400 flex items-center justify-center transition-all border border-white/5"
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          {/* Messages */}
          <div ref={scrollRef} className="flex-1 overflow-y-auto p-8 space-y-8 bg-black/40 scroll-smooth relative z-10">
            {messages.length === 0 && (
              <div className="h-full flex flex-col items-center justify-center text-center space-y-10 px-8">
                <div className="w-28 h-28 bg-zinc-900/50 rounded-[3rem] flex items-center justify-center border border-white/5 shadow-2xl relative">
                  <Sparkles className="w-14 h-14 text-purple-500 animate-pulse" />
                  <div className="absolute inset-0 bg-purple-600/10 rounded-full blur-2xl"></div>
                </div>
                <div className="space-y-4">
                  <h4 className="text-xs font-black text-white uppercase tracking-[0.4em]">Neural Safety Assistant</h4>
                  <p className="text-[10px] text-zinc-600 font-bold uppercase tracking-widest leading-relaxed px-4">
                    Main aapka digital identity secure rakhne ke liye online threats scan karunga. Kuch bhi puchiye...
                  </p>
                </div>
                <div className="grid grid-cols-1 gap-3 w-full">
                  {["Deepfake video kaise pehchane?", "Bank fraud se kaise bache?"].map((q, i) => (
                    <button 
                      key={i}
                      onClick={() => handleSend(q)} 
                      className="text-[9px] font-black uppercase tracking-widest p-5 bg-zinc-900/40 border border-white/5 rounded-[2rem] text-zinc-500 hover:border-purple-600/50 hover:text-purple-400 transition-all text-left flex items-center justify-between group active:scale-95"
                    >
                      <span className="italic">{q}</span>
                      <ChevronRight className="w-4 h-4 opacity-0 group-hover:opacity-100 text-purple-600 transition-opacity" />
                    </button>
                  ))}
                </div>
              </div>
            )}
            
            {messages.map((msg, i) => (
              <div key={msg.id} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'} animate-in slide-up`}>
                <div className={`max-w-[85%] p-6 rounded-[2.2rem] text-[13px] font-bold leading-relaxed shadow-2xl ${
                  msg.role === 'user' 
                    ? 'bg-purple-600 text-white rounded-tr-none shadow-purple-900/30' 
                    : 'bg-zinc-900 text-zinc-300 border border-white/5 rounded-tl-none shadow-black/50'
                }`}>
                  <div className="whitespace-pre-wrap">{msg.text || (isLoading && i === messages.length - 1 ? <Loader2 className="w-5 h-5 animate-spin text-purple-400" /> : '')}</div>
                </div>
              </div>
            ))}
          </div>

          {/* Input */}
          <div className="p-8 bg-zinc-900/40 border-t border-white/5 relative z-10 backdrop-blur-3xl">
            <div className="flex gap-4 bg-black border border-white/5 rounded-[2.5rem] p-3 focus-within:border-purple-600/40 transition-all shadow-2xl group">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                placeholder="Secure terminal prompt..."
                className="flex-1 bg-transparent text-xs text-zinc-100 outline-none placeholder:text-zinc-800 font-bold tracking-tight px-6"
              />
              <button 
                onClick={() => handleSend()}
                disabled={isLoading || !input.trim()}
                className="bg-purple-600 text-white p-5 rounded-[1.8rem] disabled:opacity-30 disabled:bg-zinc-800 transition-all active:scale-90 shadow-2xl shadow-purple-900/40 group-hover:shadow-purple-600/20"
              >
                {isLoading ? <Loader2 className="w-6 h-6 animate-spin" /> : <Send className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Floating Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-20 h-20 bg-purple-600 rounded-[2.5rem] flex items-center justify-center text-white shadow-[0_25px_60px_rgba(168,85,247,0.4)] pointer-events-auto hover:bg-purple-700 transition-all active:scale-90 border-4 border-white/10 relative group overflow-hidden purple-glow"
      >
        {!isOpen && (
          <div className="absolute inset-0 bg-white/20 animate-pulse group-hover:hidden"></div>
        )}
        {isOpen ? <X className="w-10 h-10" /> : <Zap className="w-10 h-10 fill-current" />}
      </button>
    </div>
  );
};

export default HinglishChatbot;
