import React, { useState } from 'react';
import { AnalysisResult, FeedbackReport } from '../types';
import { 
  ShieldCheck, AlertCircle, Info, ChevronRight, 
  Globe, Flag, CheckCircle2, Loader2, X, ShieldAlert, Zap, BarChart3
} from 'lucide-react';
import { submitFeedback } from '../services/geminiService';

interface ResultDisplayProps {
  result: AnalysisResult;
  onReset: () => void;
}

const ResultDisplay: React.FC = ({ result, onReset }) => {
  const [showFeedback, setShowFeedback] = useState(false);
  const [feedbackType, setFeedbackType] = useState<FeedbackReport['type']>('FALSE_POSITIVE');
  const [comment, setComment] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const getTheme = () => {
    switch (result.verdict) {
      case 'SAFE':
        return {
          icon: ShieldCheck,
          label: 'SECURE',
          color: 'text-emerald-400',
          bg: 'bg-emerald-500/5',
          border: 'border-emerald-500/20',
          accent: 'bg-emerald-500',
          glow: 'shadow-[0_0_50px_rgba(52,211,153,0.15)]',
          marker: 'bg-emerald-500',
        };
      case 'SUSPICIOUS':
        return {
          icon: Info,
          label: 'SUSPICIOUS',
          color: 'text-amber-400',
          bg: 'bg-amber-500/5',
          border: 'border-amber-500/20',
          accent: 'bg-amber-500',
          glow: 'shadow-[0_0_50px_rgba(245,158,11,0.15)]',
          marker: 'bg-amber-500',
        };
      default:
        return {
          icon: AlertCircle,
          label: 'BREACH',
          color: 'text-purple-400',
          bg: 'bg-purple-500/5',
          border: 'border-purple-500/20',
          accent: 'bg-purple-500',
          glow: 'shadow-[0_0_50px_rgba(168,85,247,0.2)]',
          marker: 'bg-purple-500',
        };
    }
  };

  const theme = getTheme();
  const Icon = theme.icon;

  const handleSubmitFeedback = async () => {
    setIsSubmitting(true);
    try {
      await submitFeedback({
        type: feedbackType,
        comment,
        timestamp: Date.now()
      });
      setSubmitted(true);
    } catch (error) {
      console.error("Feedback failed:", error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-8 animate-in slide-up">
      <div className={`p-12 rounded-[4rem] border-2 ${theme.border} ${theme.bg} ${theme.glow} text-center backdrop-blur-3xl relative overflow-hidden shadow-2xl group`}>
        <div className="absolute inset-0 bg-gradient-to-b from-white/5 to-transparent pointer-events-none"></div>
        
        <div className={`mx-auto w-28 h-28 rounded-[2.5rem] ${theme.color} flex items-center justify-center mb-10 bg-black/80 border border-white/5 shadow-inner group-hover:scale-110 transition-transform duration-500`}>
          <Icon className="w-14 h-14" />
        </div>
        
        <h2 className={`text-6xl font-black italic tracking-tighter ${theme.color} mb-4 uppercase`}>
          {theme.label}
        </h2>
        
        <div className="flex flex-col items-center gap-3 mb-10">
          <p className="text-zinc-600 text-[10px] font-black uppercase tracking-[0.5em] italic">Forensic Accuracy Level</p>
          <p className={`text-5xl font-black italic tracking-tighter ${theme.color}`}>{result.confidence}%</p>
        </div>

        <div className="w-full bg-black/80 rounded-full h-3.5 overflow-hidden border border-white/5 p-1 shadow-inner">
          <div 
            className={`h-full ${theme.accent} rounded-full transition-all duration-[2s] ease-out shadow-[0_0_20px_rgba(168,85,247,0.6)]`} 
            style={{ width: `${result.confidence}%` }}
          ></div>
        </div>
      </div>

      <div className="bg-zinc-950 p-10 rounded-[3.5rem] border border-white/5 shadow-2xl space-y-10 relative overflow-hidden group">
        <div className="absolute inset-0 bg-gradient-to-br from-purple-600/5 to-transparent pointer-events-none"></div>
        
        <div className="relative z-10">
          <h3 className="text-[10px] font-black text-zinc-500 uppercase tracking-[0.4em] mb-6 flex items-center gap-3">
            <Zap className="w-4 h-4 text-purple-500" />
            Neural Assessment Summary
          </h3>
          <p className="text-zinc-100 text-lg leading-relaxed italic font-bold tracking-tight">"{result.summary}"</p>
        </div>

        <div className="space-y-6 relative z-10">
          <div className="p-8 bg-zinc-900/60 rounded-[2.5rem] border border-white/5 space-y-6 shadow-xl">
            <h3 className="text-[10px] font-black text-zinc-600 uppercase tracking-[0.3em] flex items-center gap-3">
               <BarChart3 className="w-4 h-4 text-purple-600" />
               Verification Markers
            </h3>
            <ul className="space-y-5">
              {result.details.map((detail, i) => (
                <li key={i} className="flex items-start gap-5 text-[13px] text-zinc-400 font-bold leading-relaxed group/item">
                  <div className={`w-2.5 h-2.5 rounded-full mt-1 shrink-0 ${theme.marker} shadow-[0_0_8px_rgba(168,85,247,0.4)] group-hover/item:scale-125 transition-transform`} />
                  <span className="group-hover/item:text-zinc-200 transition-colors">{detail}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="p-8 bg-zinc-900/60 rounded-[2.5rem] border border-white/5 space-y-6 shadow-xl">
            <h3 className="text-[10px] font-black text-zinc-600 uppercase tracking-[0.3em] flex items-center gap-3">
               <ShieldAlert className="w-4 h-4 text-amber-500" />
               Critical Recommendations
            </h3>
            <div className="space-y-4">
              {result.recommendations.map((rec, i) => (
                <div key={i} className={`px-6 py-5 rounded-2xl text-[12px] font-black italic border flex items-center gap-5 shadow-lg ${theme.color} ${theme.bg} ${theme.border} group/rec`}>
                  <Zap className="w-5 h-5 shrink-0 animate-pulse text-purple-500" />
                  <span className="group-hover/rec:translate-x-1 transition-transform">{rec}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      <button
        onClick={onReset}
        className="w-full py-9 bg-white text-black rounded-[2.5rem] font-black uppercase tracking-[0.4em] italic hover:bg-zinc-200 active:scale-[0.98] transition-all shadow-[0_25px_60px_rgba(255,255,255,0.05)] border-t border-white/20"
      >
        Establish New Audit
      </button>
    </div>
  );
};

export default ResultDisplay;