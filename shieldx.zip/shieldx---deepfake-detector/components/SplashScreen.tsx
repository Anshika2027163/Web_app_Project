
import React from 'react';
import { ShieldCheck } from 'lucide-react';

const SplashScreen: React.FC = () => {
  return (
    <div className="min-h-screen bg-black flex flex-col items-center justify-center p-8 relative overflow-hidden">
      {/* Background Neural Particles Effect */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-purple-600/20 rounded-full blur-[120px] animate-pulse"></div>
        <div className="absolute inset-0 opacity-[0.05] bg-[linear-gradient(to_right,#808080_1px,transparent_1px),linear-gradient(to_bottom,#808080_1px,transparent_1px)] bg-[size:20px_20px]"></div>
      </div>

      <div className="relative z-10 flex flex-col items-center gap-8">
        {/* Logo Animation */}
        <div className="relative group">
          <div className="absolute inset-0 bg-purple-500 blur-2xl opacity-50 scale-150 animate-pulse"></div>
          <div className="bg-zinc-950 p-8 rounded-[3rem] border border-purple-500/30 shadow-[0_0_80px_rgba(168,85,247,0.3)] relative z-10 animate-[bounce_2s_infinite]">
            <ShieldCheck className="w-20 h-20 text-purple-500 fill-current" />
          </div>
        </div>

        {/* Text Animation */}
        <div className="text-center space-y-4 overflow-hidden">
          <h1 className="text-7xl font-black tracking-tighter text-white italic uppercase animate-[reveal_1s_ease-out_forwards]">
            SHIELD<span className="text-purple-500">X</span>
          </h1>
          <div className="h-0.5 w-0 bg-purple-500 mx-auto animate-[width-expand_1.5s_ease-in-out_forwards_0.5s]"></div>
          <p className="text-zinc-100 text-lg font-bold italic opacity-0 animate-[fade-in_1s_ease-out_forwards_1.2s]">
            "Scam aaye? ShieldX pehle bataye"
          </p>
          <p className="text-purple-300/40 text-[10px] font-bold uppercase tracking-[0.8em] opacity-0 animate-[fade-in_1s_ease-out_forwards_1.8s]">
            Neural Defense Interface
          </p>
        </div>
      </div>

      <div className="absolute bottom-12 left-0 right-0 flex flex-col items-center gap-4">
        <div className="flex gap-1.5">
          <div className="w-1.5 h-1.5 rounded-full bg-purple-600 animate-bounce [animation-delay:-0.3s]"></div>
          <div className="w-1.5 h-1.5 rounded-full bg-purple-600 animate-bounce [animation-delay:-0.15s]"></div>
          <div className="w-1.5 h-1.5 rounded-full bg-purple-600 animate-bounce"></div>
        </div>
        <p className="text-[7px] text-zinc-800 font-bold uppercase tracking-[0.5em]">Initializing Secure Core...</p>
      </div>

      <style>{`
        @keyframes reveal {
          0% { transform: translateY(100%); opacity: 0; filter: blur(10px); }
          100% { transform: translateY(0); opacity: 1; filter: blur(0); }
        }
        @keyframes width-expand {
          0% { width: 0; }
          100% { width: 100%; }
        }
        @keyframes fade-in {
          0% { opacity: 0; }
          100% { opacity: 1; }
        }
      `}</style>
    </div>
  );
};

export default SplashScreen;
