
export enum AnalysisType {
  VOICE = 'VOICE',
  MESSAGE = 'MESSAGE',
  CALL = 'CALL',
  QR = 'QR',
  IMAGE = 'IMAGE',
  VIDEO = 'VIDEO'
}

export interface AnalysisResult {
  score: number; // 0 to 100 (100 is high risk)
  confidence: number;
  verdict: 'SAFE' | 'SUSPICIOUS' | 'DANGEROUS';
  summary: string;
  details: string[];
  recommendations: string[];
  locationContext?: {
    estimatedOrigin: string;
    regionalRisk: string;
    cluesFound: string[];
    coordinates?: {
      lat: number;
      lng: number;
    };
    carrier?: string;
    timezone?: string;
    activeZone?: string; // Where they are "living" or operational based on data
  };
}

export interface ScanHistoryItem {
  id: string;
  timestamp: number;
  type: AnalysisType;
  result: AnalysisResult;
  inputSnippet: string;
}

export interface FeedbackReport {
  analysisId?: string;
  type: 'FALSE_POSITIVE' | 'FALSE_NEGATIVE' | 'INACCURATE_GEO' | 'OTHER';
  comment: string;
  timestamp: number;
}
