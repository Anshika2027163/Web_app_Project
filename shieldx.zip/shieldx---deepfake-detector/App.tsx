
import React, { useState, useEffect } from 'react';
import { HashRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Layout from './components/Layout';
import Dashboard from './pages/Dashboard';
import VoiceScanner from './pages/VoiceScanner';
import TextScanner from './pages/TextScanner';
import LiveCallGuard from './pages/LiveCallGuard';
import CallLookup from './pages/CallLookup';
import QRScanner from './pages/QRScanner';
import MediaScanner from './pages/MediaScanner';
import Settings from './pages/Settings';
import Login from './pages/Login';
import SplashScreen from './components/SplashScreen';

const App: React.FC = () => {
  const [showSplash, setShowSplash] = useState(true);
  const [userPhone, setUserPhone] = useState<string | null>(localStorage.getItem('sentinel_phone'));

  useEffect(() => {
    // Show splash screen for 5 seconds as requested
    const timer = setTimeout(() => {
      setShowSplash(false);
    }, 5000);

    return () => clearTimeout(timer);
  }, []);

  const handleLogin = (phone: string) => {
    localStorage.setItem('sentinel_phone', phone);
    setUserPhone(phone);
  };

  const handleLogout = () => {
    localStorage.removeItem('sentinel_phone');
    setUserPhone(null);
  };

  if (showSplash) {
    return <SplashScreen />;
  }

  if (!userPhone) {
    return <Login onLogin={handleLogin} />;
  }

  return (
    <Router>
      <Layout>
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/voice" element={<VoiceScanner />} />
          <Route path="/qr" element={<QRScanner />} />
          <Route path="/text" element={<TextScanner />} />
          <Route path="/lookup" element={<CallLookup />} />
          <Route path="/live" element={<LiveCallGuard />} />
          <Route path="/media" element={<MediaScanner />} />
          <Route path="/settings" element={<Settings />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </Layout>
    </Router>
  );
};

export default App;
