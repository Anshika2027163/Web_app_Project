
import React, { useState } from 'react';
import { MessageSquare, ShieldAlert, Loader2, AlertCircle, Copy } from 'lucide-react';
import { analyzeContent } from '../services/geminiService';
import { AnalysisResult, AnalysisType } from '../types';
import ResultDisplay from '../components/ResultDisplay';

const TextScanner: React.FC = () => {
  const [inputText, setInputText] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleAnalyze = async () => {
    if (!inputText.trim()) return;
    setIsAnalyzing(true);
    setError(null);
    try {
      const analysis = await analyzeContent(
        inputText, 
        AnalysisType.MESSAGE
      );
      setResult(analysis);
    } catch (err) {
      setError("Analysis core failure. Content rejected.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  const pasteClipboard = async () => {
    try {
      const text = await navigator.clipboard.readText();
      setInputText(text);
    } catch (err) {
      setError("Clipboard access denied by system protocol.");
    }
  };

  if (result) {
    return <ResultDisplay result={result} onReset={() => {
      setResult(null);
      setInputText('');
    }} />;
  }

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-2">
      <div className="text-center space-y-2">
        <h2 className="text-2xl font-black text-white italic tracking-tighter uppercase">Fraud Text Audit</h2>
        <p className="text-zinc-500 text-[11px] font-bold uppercase tracking-widest">Input suspicious fragments for pattern analysis</p>
      </div>

      <div className="bg-zinc-950 rounded-[32px] border border-zinc-900 shadow-2xl overflow-hidden focus-within:border-red-900/50 focus-within:shadow-[0_0_20px_rgba(220,38,38,0.1)] transition-all">
        <textarea
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          placeholder="PASTE SUSPICIOUS PAYLOAD HERE..."
          className="w-full h-56 p-6 bg-black text-zinc-200 placeholder:text-zinc-800 resize-none outline-none text-sm font-medium leading-relaxed"
        />
        <div className="bg-zinc-950 px-6 py-4 flex items-center justify-between border-t border-zinc-900">
          <button 
            onClick={pasteClipboard}
            className="flex items-center gap-2 text-[10px] font-black text-zinc-600 hover:text-red-500 transition-colors uppercase tracking-widest"
          >
            <Copy className="w-3.5 h-3.5" />
            Paste Buffer
          </button>
        </div>
      </div>

      <button
        onClick={handleAnalyze}
        disabled={!inputText.trim() || isAnalyzing}
        className="w-full py-5 bg-red-600 text-white rounded-2xl font-black uppercase tracking-[0.2em] italic flex items-center justify-center gap-3 shadow-[0_10px_30px_rgba(220,38,38,0.2)] hover:bg-red-700 active:scale-[0.98] transition-all disabled:bg-zinc-900 disabled:text-zinc-700 disabled:shadow-none border border-red-500/20"
      >
        {isAnalyzing ? (
          <>
            <Loader2 className="w-5 h-5 animate-spin" />
            Parsing Content...
          </>
        ) : (
          <>
            <ShieldAlert className="w-5 h-5" />
            Run Security Audit
          </>
        )}
      </button>

      {error && (
        <div className="p-4 bg-red-950/20 border border-red-900/50 rounded-2xl flex items-start gap-3 text-red-500 text-[10px] font-black uppercase tracking-widest leading-relaxed">
          <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
          <p>{error}</p>
        </div>
      )}

      <div className="p-5 bg-zinc-900/50 rounded-2xl border border-zinc-800 space-y-2">
        <h4 className="text-[10px] font-black text-red-500 uppercase tracking-widest flex items-center gap-2">
          <AlertCircle className="w-3.5 h-3.5" />
          SECURE PROTOCOL
        </h4>
        <p className="text-[11px] text-zinc-500 leading-relaxed italic font-medium">
          ShieldX analyzes text fragments for linguistic shifts, known fraud scripts, and social engineering patterns.
        </p>
      </div>
    </div>
  );
};

export default TextScanner;
