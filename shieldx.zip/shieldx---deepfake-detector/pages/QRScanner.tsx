
import React, { useState, useRef, useEffect } from 'react';
import { QrCode, Camera, Loader2, AlertCircle, RefreshCw, ShieldCheck, ShieldAlert, Upload, Image as ImageIcon } from 'lucide-react';
import jsQR from 'jsqr';
import { analyzeContent } from '../services/geminiService';
import { AnalysisResult, AnalysisType } from '../types';
import ResultDisplay from '../components/ResultDisplay';

const QRScanner: React.FC = () => {
  const [isScanning, setIsScanning] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [scanResult, setScanResult] = useState<string | null>(null);
  const [analysis, setAnalysis] = useState<AnalysisResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const requestRef = useRef<number>();

  const startCamera = async () => {
    try {
      setError(null);
      setScanResult(null);
      setIsScanning(true);
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: 'environment' } 
      });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.setAttribute("playsinline", "true"); 
        videoRef.current.play();
        requestRef.current = requestAnimationFrame(tick);
      }
    } catch (err) {
      console.error(err);
      setError("Optical Sensor Access Denied: Camera not detected or permission revoked.");
      setIsScanning(false);
    }
  };

  const stopCamera = () => {
    setIsScanning(false);
    if (requestRef.current) {
      cancelAnimationFrame(requestRef.current);
    }
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach(track => track.stop());
    }
  };

  const tick = () => {
    if (videoRef.current && videoRef.current.readyState === videoRef.current.HAVE_ENOUGH_DATA && canvasRef.current) {
      const canvas = canvasRef.current;
      const context = canvas.getContext('2d');
      if (context) {
        canvas.height = videoRef.current.videoHeight;
        canvas.width = videoRef.current.videoWidth;
        context.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
        const imageData = context.getImageData(0, 0, canvas.width, canvas.height);
        const code = jsQR(imageData.data, imageData.width, imageData.height, {
          inversionAttempts: "dontInvert",
        });

        if (code) {
          setScanResult(code.data);
          stopCamera();
          handleAnalyze(code.data);
          return;
        }
      }
    }
    requestRef.current = requestAnimationFrame(tick);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setError(null);
    setIsAnalyzing(true);

    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const context = canvas.getContext('2d');
        if (!context) {
          setError("Canvas rendering failed.");
          setIsAnalyzing(false);
          return;
        }

        canvas.width = img.width;
        canvas.height = img.height;
        context.drawImage(img, 0, 0);
        const imageData = context.getImageData(0, 0, canvas.width, canvas.height);
        const code = jsQR(imageData.data, imageData.width, imageData.height);

        if (code) {
          setScanResult(code.data);
          handleAnalyze(code.data);
        } else {
          setError("No valid QR code detected in the uploaded image.");
          setIsAnalyzing(false);
        }
      };
      img.onerror = () => {
        setError("Failed to load image file.");
        setIsAnalyzing(false);
      };
      img.src = event.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  const handleAnalyze = async (data: string) => {
    setIsAnalyzing(true);
    setError(null);
    try {
      const result = await analyzeContent(data, AnalysisType.QR);
      setAnalysis(result);
    } catch (err) {
      setError("Analysis core failure. Metadata scan rejected.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  useEffect(() => {
    return () => stopCamera();
  }, []);

  if (analysis) {
    return (
      <div className="space-y-4">
        <div className="bg-zinc-900 p-5 rounded-3xl border border-zinc-800 flex items-center justify-between shadow-xl">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-red-600/10 rounded-xl text-red-500 border border-red-900/30">
              <QrCode className="w-5 h-5" />
            </div>
            <div className="overflow-hidden">
              <p className="text-[10px] text-zinc-500 font-black uppercase tracking-widest">Payload Intercepted</p>
              <p className="text-xs font-bold text-white truncate max-w-[180px]">{scanResult}</p>
            </div>
          </div>
          <button 
            onClick={() => {
              setAnalysis(null);
              setScanResult(null);
              setError(null);
            }}
            className="p-2 bg-zinc-800 text-zinc-400 rounded-xl hover:text-white transition-colors"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
        <ResultDisplay result={analysis} onReset={() => {
          setAnalysis(null);
          setScanResult(null);
          setError(null);
        }} />
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-2">
      <div className="text-center space-y-2">
        <h2 className="text-2xl font-black text-white italic tracking-tighter uppercase">Optical Data Audit</h2>
        <p className="text-zinc-500 text-[11px] font-bold uppercase tracking-widest">Scan or upload QR codes to detect phishing</p>
      </div>

      <div className="relative group">
        <div className={`w-full aspect-square rounded-[2.5rem] bg-zinc-950 border-2 border-zinc-900 flex flex-col items-center justify-center overflow-hidden transition-all relative ${isScanning ? 'border-red-600/50 shadow-[0_0_40px_rgba(220,38,38,0.1)]' : ''}`}>
          {isScanning ? (
            <>
              <video ref={videoRef} className="w-full h-full object-cover" />
              <canvas ref={canvasRef} className="hidden" />
              {/* Scan Overlay */}
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                 <div className="w-64 h-64 border-2 border-red-600/40 rounded-3xl relative overflow-hidden">
                    <div className="absolute top-0 left-0 right-0 h-0.5 bg-red-500 shadow-[0_0_15px_rgba(220,38,38,1)] animate-[scan_3s_ease-in-out_infinite]" />
                 </div>
              </div>
              <style>{`
                @keyframes scan {
                  0%, 100% { top: 0; }
                  50% { top: 100%; }
                }
              `}</style>
            </>
          ) : isAnalyzing ? (
            <div className="flex flex-col items-center gap-6 animate-in fade-in">
               <Loader2 className="w-16 h-16 text-red-600 animate-spin" />
               <div className="text-center">
                  <h3 className="text-lg font-black text-white italic uppercase">Parsing Optical Data</h3>
                  <p className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest mt-1">Cross-referencing malicious registries...</p>
               </div>
            </div>
          ) : (
            <div className="flex flex-col items-center gap-6 px-10 text-center">
               <div className="w-20 h-20 bg-zinc-900 rounded-3xl flex items-center justify-center border border-zinc-800 text-zinc-700">
                  <QrCode className="w-10 h-10" />
               </div>
               <p className="text-[10px] font-black text-zinc-600 uppercase tracking-[0.2em] leading-relaxed">
                  Active Sensor Feed or Data Upload Required
               </p>
            </div>
          )}
        </div>
      </div>

      {!isScanning && !isAnalyzing && (
        <div className="space-y-4">
          <button
            onClick={startCamera}
            className="w-full py-6 bg-red-600 text-white rounded-3xl font-black text-lg uppercase tracking-[0.2em] italic shadow-[0_15px_40px_rgba(220,38,38,0.3)] hover:bg-red-700 active:scale-[0.98] transition-all flex items-center justify-center gap-4 border border-red-500/20"
          >
            <Camera className="w-7 h-7" />
            Activate Optical Sensor
          </button>

          <div className="w-full flex items-center gap-4 py-2">
            <div className="h-px bg-zinc-900 flex-1"></div>
            <span className="text-[10px] font-black text-zinc-700 uppercase tracking-[0.3em]">Manual Import</span>
            <div className="h-px bg-zinc-900 flex-1"></div>
          </div>

          <label className="w-full block">
            <div className="flex items-center justify-center gap-3 p-5 border-2 border-dashed border-zinc-900 rounded-3xl hover:border-red-900 transition-all cursor-pointer bg-zinc-950 group">
              <Upload className="w-5 h-5 text-zinc-600 group-hover:text-red-500 transition-colors" />
              <span className="text-xs font-black text-zinc-500 uppercase tracking-widest group-hover:text-zinc-300">Upload Target QR</span>
            </div>
            <input 
              type="file" 
              accept="image/*" 
              onChange={handleFileUpload} 
              className="hidden" 
            />
          </label>
        </div>
      )}

      {isScanning && (
        <button
          onClick={stopCamera}
          className="w-full py-6 bg-zinc-900 text-red-500 rounded-3xl font-black text-lg uppercase tracking-[0.2em] italic border border-red-900/30 hover:bg-zinc-800 transition-all flex items-center justify-center gap-4"
        >
          Cancel Scan
        </button>
      )}

      {error && (
        <div className="p-4 bg-red-950/20 border border-red-900/50 rounded-2xl flex items-start gap-3 text-red-500 text-[10px] font-black uppercase tracking-widest leading-relaxed animate-in fade-in">
          <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
          <p>{error}</p>
        </div>
      )}

      <div className="p-5 bg-zinc-900/50 rounded-2xl border border-zinc-800 space-y-3">
        <h4 className="text-[10px] font-black text-red-500 uppercase tracking-widest flex items-center gap-2">
          <ShieldAlert className="w-3.5 h-3.5" />
          FRAUD PROTOCOL
        </h4>
        <p className="text-[11px] text-zinc-500 leading-relaxed font-bold uppercase tracking-widest italic">
          ShieldX analyzes QR destination URIs for phishing patterns, deceptive redirects, and unauthorized payment gateway requests.
        </p>
      </div>
    </div>
  );
};

export default QRScanner;
