
import React, { useState, useEffect } from 'react';
import { Search, Loader2, AlertCircle, Phone, Globe, ShieldAlert, ExternalLink, Radar, Crosshair, Signal } from 'lucide-react';
import { analyzePhoneNumber } from '../services/geminiService';
import { AnalysisResult } from '../types';
import ResultDisplay from '../components/ResultDisplay';

const CallLookup: React.FC = () => {
  const [number, setNumber] = useState('');
  const [context, setContext] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<(AnalysisResult & { sources?: { title: string; uri: string }[] }) | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [scanStep, setScanStep] = useState(0);

  const scanMessages = [
    "Querying Global Repositories...",
    "Bypassing Proxy Layers...",
    "Querying Carrier Databases...",
    "Checking Fraud Reputations...",
    "Finalizing Intelligence Audit..."
  ];

  useEffect(() => {
    let interval: any;
    if (isAnalyzing) {
      interval = setInterval(() => {
        setScanStep(prev => (prev + 1) % scanMessages.length);
      }, 2000);
    }
    return () => clearInterval(interval);
  }, [isAnalyzing]);

  const handleLookup = async () => {
    if (!number.trim()) return;
    setIsAnalyzing(true);
    setScanStep(0);
    setError(null);
    try {
      const data = await analyzePhoneNumber(number, context);
      setResult(data);
    } catch (err) {
      setError("Deep search protocol interrupted. AI Core returned an invalid response.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  if (result) {
    return (
      <div className="space-y-6">
        <ResultDisplay result={result} onReset={() => {
          setResult(null);
          setNumber('');
          setContext('');
        }} />
        
        {result.sources && result.sources.length > 0 && (
          <div className="bg-zinc-950 p-6 rounded-3xl border border-zinc-900 shadow-sm animate-in fade-in slide-up">
            <h3 className="text-[10px] font-black text-zinc-500 uppercase tracking-[0.2em] mb-4 flex items-center gap-2">
              <Globe className="w-4 h-4 text-emerald-500" />
              Intelligence Sources
            </h3>
            <div className="space-y-3">
              {result.sources.map((source, i) => (
                <a 
                  key={i} 
                  href={source.uri} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="flex items-center justify-between p-3 bg-zinc-900 border border-zinc-800 rounded-xl hover:bg-zinc-800 transition-colors group"
                >
                  <span className="text-xs font-bold text-zinc-400 group-hover:text-white truncate pr-4">{source.title}</span>
                  <ExternalLink className="w-3.5 h-3.5 text-zinc-600 group-hover:text-emerald-500 shrink-0" />
                </a>
              ))}
            </div>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-2">
      <div className="text-center space-y-2">
        <h2 className="text-2xl font-black text-white italic tracking-tighter uppercase">Origin Trace</h2>
        <p className="text-zinc-500 text-[11px] font-bold uppercase tracking-widest">Global reputation lookup & database sweep</p>
      </div>

      {!isAnalyzing ? (
        <>
          <div className="space-y-4">
            <div className="relative group">
              <div className="absolute inset-y-0 left-5 flex items-center pointer-events-none">
                <Phone className="w-5 h-5 text-zinc-700 group-focus-within:text-red-600 transition-colors" />
              </div>
              <input
                type="tel"
                value={number}
                onChange={(e) => setNumber(e.target.value)}
                placeholder="ENTER TARGET NUMBER..."
                className="w-full pl-14 pr-6 py-5 bg-zinc-950 border border-zinc-900 rounded-[24px] text-white placeholder:text-zinc-800 outline-none focus:border-red-600/50 focus:shadow-[0_0_20px_rgba(220,38,38,0.1)] transition-all font-black italic tracking-wider"
              />
            </div>

            <textarea
              value={context}
              onChange={(e) => setContext(e.target.value)}
              placeholder="ADDITIONAL CONTEXT (E.G. 'CLAIMED TO BE FROM BANK')"
              className="w-full h-32 p-6 bg-zinc-950 border border-zinc-900 rounded-[24px] text-white placeholder:text-zinc-800 outline-none focus:border-red-600/50 resize-none text-xs font-bold leading-relaxed uppercase tracking-tighter"
            />
          </div>

          <button
            onClick={handleLookup}
            disabled={!number.trim() || isAnalyzing}
            className="w-full py-6 bg-red-600 text-white rounded-[24px] font-black uppercase tracking-[0.2em] italic flex items-center justify-center gap-3 shadow-[0_10px_30px_rgba(220,38,38,0.2)] hover:bg-red-700 active:scale-[0.98] transition-all disabled:bg-zinc-900 disabled:text-zinc-800 disabled:shadow-none border border-red-500/20"
          >
            <Search className="w-6 h-6" />
            Initiate Deep Trace
          </button>
        </>
      ) : (
        <div className="py-20 flex flex-col items-center justify-center space-y-8 animate-in fade-in">
           <div className="relative">
              <div className="absolute inset-0 bg-red-600/10 rounded-full animate-ping [animation-duration:3s]"></div>
              <div className="w-48 h-48 rounded-full border border-red-900/30 flex items-center justify-center relative bg-black">
                 <Radar className="w-24 h-24 text-red-600 animate-spin [animation-duration:4s]" />
                 <Crosshair className="absolute w-8 h-8 text-white animate-pulse" />
              </div>
           </div>
           <div className="text-center space-y-3">
              <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-red-950/20 border border-red-900/30 rounded-full text-[10px] font-black text-red-500 uppercase tracking-[0.2em]">
                 <Signal className="w-3 h-3 animate-bounce" />
                 Active Database sweep
              </div>
              <p className="text-lg font-black text-white italic tracking-tighter uppercase">{scanMessages[scanStep]}</p>
              <div className="flex gap-1 justify-center">
                 {[0,1,2,3,4].map(i => (
                   <div key={i} className={`h-1 w-8 rounded-full transition-colors ${i <= scanStep ? 'bg-red-600' : 'bg-zinc-800'}`}></div>
                 ))}
              </div>
           </div>
        </div>
      )}

      {error && (
        <div className="p-4 bg-red-950/20 border border-red-900/50 rounded-2xl flex items-start gap-3 text-red-500 text-[10px] font-black uppercase tracking-widest leading-relaxed">
          <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
          <p>{error}</p>
        </div>
      )}

      <div className="p-5 bg-zinc-900/50 rounded-2xl border border-zinc-800 space-y-3">
        <h4 className="text-[10px] font-black text-red-500 uppercase tracking-widest flex items-center gap-2">
          <ShieldAlert className="w-3.5 h-3.5" />
          SYSTEM ALERT
        </h4>
        <p className="text-[11px] text-zinc-500 leading-relaxed font-bold uppercase tracking-widest italic">
          ShieldX cross-references area codes and number patterns with global fraud clusters to identify high-risk origin points.
        </p>
      </div>
    </div>
  );
};

export default CallLookup;
