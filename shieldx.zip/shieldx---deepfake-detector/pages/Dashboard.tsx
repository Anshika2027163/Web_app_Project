import React from 'react';
import { ShieldAlert, TrendingUp, History, Bell, ChevronRight, ShieldCheck, AlertCircle, Settings, QrCode, Search, Eye, Zap, Fingerprint, Mic } from 'lucide-react';
import { Link } from 'react-router-dom';

const Dashboard: React.FC = () => {
  return (
    <div className="space-y-8 slide-up">
      {/* Risk Assessment Card */}
      <div className="bg-gradient-to-br from-purple-700 via-zinc-900 to-black p-8 rounded-[3rem] text-white shadow-[0_25px_60px_rgba(124,58,237,0.2)] relative overflow-hidden border border-white/10 purple-glow group">
        <div className="absolute top-0 right-0 p-8 opacity-10 group-hover:scale-110 transition-transform duration-700">
          <Fingerprint className="w-24 h-24 text-purple-400" />
        </div>
        
        <div className="relative z-10 space-y-6">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              <p className="text-purple-200 text-[10px] font-bold uppercase tracking-[0.3em] opacity-70">Neural Link Active</p>
            </div>
            <h2 className="text-3xl font-black tracking-tighter text-white italic uppercase">Operational Status</h2>
          </div>
          
          <div className="flex items-center gap-10">
            <div className="space-y-1">
              <p className="text-[10px] text-purple-300 uppercase font-bold tracking-widest">Total Scans</p>
              <p className="text-4xl font-bold tracking-tighter text-white">2,491</p>
            </div>
            <div className="w-px h-10 bg-white/10"></div>
            <div className="space-y-1">
              <p className="text-[10px] text-purple-300 uppercase font-bold tracking-widest">Threats Blocked</p>
              <p className="text-4xl font-bold tracking-tighter text-purple-400">107</p>
            </div>
          </div>

          <div className="pt-2">
            <div className="px-5 py-3 bg-white/10 rounded-2xl w-full border border-white/5 backdrop-blur-md flex items-center justify-between">
              <span className="text-[10px] font-bold uppercase tracking-widest text-zinc-100">Quantum Encryption Layer</span>
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
            </div>
          </div>
        </div>
        
        {/* Background glow effects */}
        <div className="absolute top-[-30%] right-[-10%] w-64 h-64 bg-purple-600/20 rounded-full blur-[100px]"></div>
      </div>

      {/* Audit protocols matrix */}
      <div>
        <div className="flex items-center justify-between mb-5 px-1">
          <h3 className="text-xs font-bold text-zinc-500 uppercase tracking-[0.2em]">Security Matrix</h3>
          <Zap className="w-4 h-4 text-purple-500" />
        </div>
        <div className="grid grid-cols-2 gap-4">
          <Link to="/media" className="col-span-2 bg-zinc-900/60 p-6 rounded-[2.5rem] border border-white/5 flex items-center gap-6 active:scale-[0.98] transition-all hover:bg-zinc-800/80 group relative overflow-hidden shadow-2xl">
            <div className="absolute inset-0 bg-gradient-to-r from-purple-600/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
            <div className="w-16 h-16 bg-zinc-800 text-purple-500 rounded-2xl flex items-center justify-center border border-white/5 shadow-inner">
              <Eye className="w-8 h-8 group-hover:scale-110 transition-transform" />
            </div>
            <div className="relative z-10">
              <h4 className="text-sm font-bold text-zinc-100 uppercase tracking-tight">Visual Forensic</h4>
              <p className="text-[10px] text-zinc-500 font-bold uppercase tracking-widest mt-1 italic">Pixel-Level Audit</p>
            </div>
          </Link>

          <Link to="/voice" className="bg-zinc-900/40 p-5 rounded-[2rem] border border-white/5 flex flex-col items-center gap-4 text-center active:scale-[0.97] transition-all hover:bg-zinc-800/80 hover:border-purple-500/30 group">
            <div className="w-14 h-14 bg-zinc-800 text-zinc-400 rounded-2xl flex items-center justify-center border border-white/5 group-hover:text-purple-400 transition-colors shadow-lg">
              <Mic className="w-6 h-6" />
            </div>
            <span className="text-[10px] font-bold text-zinc-300 uppercase tracking-widest">Vocal Trace</span>
          </Link>

          <Link to="/lookup" className="bg-zinc-900/40 p-5 rounded-[2rem] border border-white/5 flex flex-col items-center gap-4 text-center active:scale-[0.97] transition-all hover:bg-zinc-800/80 hover:border-purple-500/30 group">
            <div className="w-14 h-14 bg-zinc-800 text-zinc-400 rounded-2xl flex items-center justify-center border border-white/5 group-hover:text-purple-400 transition-colors shadow-lg">
              <Search className="w-6 h-6" />
            </div>
            <span className="text-[10px] font-bold text-zinc-300 uppercase tracking-widest">Global Lookup</span>
          </Link>
        </div>
      </div>

      {/* Intelligence Logs */}
      <div>
        <div className="flex items-center justify-between mb-5 px-1">
          <h3 className="text-xs font-bold text-zinc-500 uppercase tracking-[0.2em]">Operational Intel</h3>
          <History className="w-4 h-4 text-zinc-700" />
        </div>
        <div className="space-y-4">
          {[
            { type: 'Media Scan', time: '12m ago', status: 'Threat', acc: 98.4, color: 'purple', icon: Eye },
            { type: 'Vocal Verification', time: '2h ago', status: 'Secure', acc: 99.1, color: 'zinc', icon: ShieldCheck },
            { type: 'QR Audit', time: '5h ago', status: 'Secure', acc: 100, color: 'zinc', icon: ShieldCheck }
          ].map((item, i) => (
            <div key={i} className="bg-zinc-900/30 p-5 rounded-[2.2rem] border border-white/5 flex items-center gap-5 hover:bg-zinc-900 transition-all group active:scale-95">
              <div className={`w-14 h-14 ${item.color === 'purple' ? 'bg-purple-950/40 text-purple-400' : 'bg-zinc-800 text-zinc-500'} rounded-2xl flex items-center justify-center shrink-0 border border-white/5 group-hover:scale-110 transition-transform`}>
                <item.icon className="w-6 h-6" />
              </div>
              <div className="flex-1">
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-zinc-100 text-sm tracking-tight italic uppercase">{item.type}</h4>
                  <span className={`text-[10px] font-bold uppercase tracking-widest ${item.color === 'purple' ? 'text-purple-400' : 'text-zinc-500'}`}>{item.status}</span>
                </div>
                <div className="flex items-center gap-2 mt-1">
                   <p className="text-[10px] text-zinc-600 font-bold uppercase tracking-tight">{item.time}</p>
                   <div className="w-1 h-1 rounded-full bg-zinc-800"></div>
                   <p className="text-[10px] text-purple-500/50 font-bold uppercase tracking-tight">Confidence: {item.acc}%</p>
                </div>
              </div>
              <ChevronRight className="w-5 h-5 text-zinc-800 group-hover:text-purple-500 transition-colors" />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;