
import React, { useState } from 'react';
import { 
  User, Shield, Bell, Trash2, LogOut, ChevronRight, 
  Info, Cpu, Database, Smartphone, Lock, Zap, Activity, Fingerprint
} from 'lucide-react';

const Settings: React.FC = () => {
  const userPhone = localStorage.getItem('sentinel_phone') || 'UNREGISTERED';
  const [notifications, setNotifications] = useState(true);
  const [autoTrace, setAutoTrace] = useState(true);
  const [highSensitivity, setHighSensitivity] = useState(false);

  const handleLogout = () => {
    localStorage.removeItem('sentinel_phone');
    window.location.reload();
  };

  const handleClearHistory = () => {
    if (confirm("PROTOCOL ALERT: This will purge all local scan logs and intelligence metadata. Proceed?")) {
      alert("Local data fragments purged.");
    }
  };

  const SettingToggle = ({ label, description, active, onToggle }: { label: string, description: string, active: boolean, onToggle: () => void }) => (
    <div className="flex items-center justify-between p-5 bg-zinc-900/40 rounded-[2rem] border border-white/5 backdrop-blur-xl group transition-all hover:bg-zinc-900/60">
      <div className="space-y-1">
        <p className="text-[11px] font-black text-zinc-100 uppercase tracking-wider italic">{label}</p>
        <p className="text-[9px] text-zinc-500 font-bold uppercase tracking-widest">{description}</p>
      </div>
      <button 
        onClick={onToggle}
        className={`w-14 h-7 rounded-full transition-all relative shadow-inner ${active ? 'bg-purple-600 shadow-[0_0_15px_rgba(168,85,247,0.4)]' : 'bg-zinc-800'}`}
      >
        <div className={`absolute top-1.5 w-4 h-4 bg-white rounded-full transition-all shadow-xl ${active ? 'right-1.5' : 'left-1.5'}`} />
      </button>
    </div>
  );

  return (
    <div className="space-y-10 animate-in fade-in slide-up">
      <div className="text-center space-y-3">
        <h2 className="text-3xl font-black text-white italic tracking-tighter uppercase">System Config</h2>
        <p className="text-zinc-500 text-[10px] font-bold uppercase tracking-[0.3em]">Neural defense parameter control</p>
      </div>

      {/* User Identity Section */}
      <section className="space-y-4">
        <div className="flex items-center justify-between px-1">
          <h3 className="text-[10px] font-black text-zinc-500 uppercase tracking-[0.4em]">Operator Identity</h3>
          <Fingerprint className="w-4 h-4 text-purple-600/40" />
        </div>
        <div className="bg-zinc-950 p-7 rounded-[2.5rem] border border-white/5 shadow-2xl flex items-center gap-5 relative overflow-hidden group">
          <div className="absolute inset-0 bg-gradient-to-br from-purple-600/10 to-transparent pointer-events-none"></div>
          <div className="w-16 h-16 bg-zinc-900 border border-purple-500/20 rounded-2xl flex items-center justify-center text-purple-500 shrink-0 shadow-inner group-hover:scale-110 transition-transform duration-500">
            <User className="w-8 h-8" />
          </div>
          <div className="flex-1 relative z-10">
            <p className="text-[9px] text-zinc-500 font-black uppercase tracking-widest mb-1">Linked Terminal</p>
            <p className="text-xl font-black text-white italic tracking-tighter">{userPhone}</p>
          </div>
          <div className="absolute bottom-[-10px] right-[-10px] opacity-10 rotate-12">
            <Smartphone className="w-20 h-20 text-white" />
          </div>
        </div>
      </section>

      {/* Security Parameters */}
      <section className="space-y-4">
        <div className="flex items-center justify-between px-1">
          <h3 className="text-[10px] font-black text-zinc-500 uppercase tracking-[0.4em]">Defense Protocols</h3>
          <Shield className="w-4 h-4 text-purple-500" />
        </div>
        <div className="space-y-4">
          <SettingToggle 
            label="Real-time Intercept" 
            description="Passive neural signal monitoring" 
            active={autoTrace} 
            onToggle={() => setAutoTrace(!autoTrace)} 
          />
          <SettingToggle 
            label="Neural Sensitivity" 
            description="Aggressive artifact verification" 
            active={highSensitivity} 
            onToggle={() => setHighSensitivity(!highSensitivity)} 
          />
          <SettingToggle 
            label="Threat Notifications" 
            description="Instant biometric risk alerts" 
            active={notifications} 
            onToggle={() => setNotifications(!notifications)} 
          />
        </div>
      </section>

      {/* Data Management */}
      <section className="space-y-4">
        <div className="flex items-center justify-between px-1">
          <h3 className="text-[10px] font-black text-zinc-500 uppercase tracking-[0.4em]">Storage & Session</h3>
          <Database className="w-4 h-4 text-zinc-700" />
        </div>
        <div className="space-y-4">
          <button 
            onClick={handleClearHistory}
            className="w-full flex items-center justify-between p-6 bg-zinc-900/30 rounded-[2rem] border border-white/5 hover:bg-zinc-800/50 transition-all group active:scale-95 shadow-lg"
          >
            <div className="flex items-center gap-4">
              <div className="p-3 bg-zinc-950 rounded-xl group-hover:text-purple-500 border border-white/5">
                <Trash2 className="w-4 h-4" />
              </div>
              <span className="text-xs font-black text-zinc-400 uppercase tracking-widest italic group-hover:text-zinc-100">Purge Intel Logs</span>
            </div>
            <ChevronRight className="w-5 h-5 text-zinc-800 group-hover:text-purple-500" />
          </button>

          <button 
            onClick={handleLogout}
            className="w-full flex items-center justify-between p-6 bg-purple-950/10 rounded-[2rem] border border-purple-500/10 hover:bg-purple-900/20 transition-all group active:scale-95 shadow-xl"
          >
            <div className="flex items-center gap-4">
              <div className="p-3 bg-purple-600/20 text-purple-400 rounded-xl border border-purple-500/20 shadow-[0_0_15px_rgba(168,85,247,0.1)]">
                <LogOut className="w-4 h-4" />
              </div>
              <span className="text-xs font-black text-purple-400 uppercase tracking-widest italic">Terminate Session</span>
            </div>
            <ChevronRight className="w-5 h-5 text-purple-900 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>
      </section>

      {/* Technical Specs */}
      <section className="bg-zinc-900/30 backdrop-blur-2xl p-8 rounded-[3rem] border border-white/5 space-y-6 shadow-2xl relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-purple-600/5 to-transparent pointer-events-none"></div>
        
        <div className="flex items-center gap-3 text-zinc-600 relative z-10">
          <Zap className="w-4 h-4 text-purple-500" />
          <span className="text-[10px] font-black uppercase tracking-[0.3em]">ShieldX Diagnostics</span>
        </div>
        
        <div className="grid grid-cols-2 gap-6 relative z-10">
          <div className="space-y-2">
            <p className="text-[8px] text-zinc-600 font-black uppercase tracking-widest">Neural Core</p>
            <div className="flex items-center gap-2 text-[10px] font-black text-zinc-300 italic">
              <Cpu className="w-3.5 h-3.5 text-purple-500" />
              Gemini 3 Flash
            </div>
          </div>
          <div className="space-y-2">
            <p className="text-[8px] text-zinc-600 font-black uppercase tracking-widest">Kernel Version</p>
            <div className="flex items-center gap-2 text-[10px] font-black text-zinc-300 italic">
              <Activity className="w-3.5 h-3.5 text-purple-500" />
              v4.5.1 STABLE
            </div>
          </div>
        </div>

        <div className="pt-5 border-t border-white/5 flex items-center justify-center gap-2 text-zinc-800 relative z-10">
          <Lock className="w-3.5 h-3.5" />
          <span className="text-[9px] font-black uppercase tracking-[0.5em] italic">Quantum Sealed Pipeline</span>
        </div>
      </section>
    </div>
  );
};

export default Settings;
