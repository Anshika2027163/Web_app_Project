
import React, { useState } from 'react';
import { Upload, Image as ImageIcon, Video, Loader2, AlertCircle, ShieldAlert, Eye, Lock, ShieldCheck, X, Zap } from 'lucide-react';
import { analyzeContent } from '../services/geminiService';
import { AnalysisResult, AnalysisType } from '../types';
import ResultDisplay from '../components/ResultDisplay';

const MediaScanner: React.FC = () => {
  const [mediaFile, setMediaFile] = useState<File | null>(null);
  const [pendingFile, setPendingFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [showPermission, setShowPermission] = useState(false);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [mediaType, setMediaType] = useState<AnalysisType>(AnalysisType.IMAGE);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setPendingFile(file);
      setShowPermission(true);
      setError(null);
      e.target.value = '';
    }
  };

  const confirmPermission = () => {
    if (pendingFile) {
      setMediaFile(pendingFile);
      const url = URL.createObjectURL(pendingFile);
      setPreviewUrl(url);
      setMediaType(pendingFile.type.startsWith('video/') ? AnalysisType.VIDEO : AnalysisType.IMAGE);
      setPendingFile(null);
      setShowPermission(false);
    }
  };

  const denyPermission = () => {
    setPendingFile(null);
    setShowPermission(false);
    setError("Action aborted by operator. Core access rejected.");
  };

  const handleAnalyze = async () => {
    if (!mediaFile) return;
    setIsAnalyzing(true);
    setError(null);
    try {
      const analysis = await analyzeContent(
        mediaFile, 
        mediaType,
        mediaFile.type
      );
      setResult(analysis);
    } catch (err) {
      setError("Forensic scan failure. Neural buffer overflow or timeout.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  if (result) {
    return <ResultDisplay result={result} onReset={() => {
      setResult(null);
      setMediaFile(null);
      setPreviewUrl(null);
    }} />;
  }

  return (
    <div className="space-y-10 animate-in slide-up relative">
      {/* Auth Overlay */}
      {showPermission && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-8 bg-black/95 backdrop-blur-2xl animate-in fade-in duration-500">
          <div className="w-full max-w-sm bg-zinc-950 border border-purple-500/20 rounded-[3rem] p-10 space-y-10 shadow-[0_0_100px_rgba(168,85,247,0.15)] relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-purple-600 to-transparent animate-pulse" />
            
            <div className="flex flex-col items-center text-center space-y-8">
              <div className="w-24 h-24 bg-purple-600/10 rounded-[2.5rem] flex items-center justify-center border border-purple-500/20 text-purple-600">
                <Lock className="w-12 h-12" />
              </div>
              
              <div className="space-y-3">
                <h3 className="text-2xl font-black text-white italic uppercase tracking-tight">Security Clearance</h3>
                <p className="text-[10px] text-zinc-500 font-bold uppercase tracking-[0.2em] leading-relaxed">
                  Authorize neural ingest for pixel-level forensic deep-scan.
                </p>
              </div>

              <div className="w-full space-y-4">
                <button
                  onClick={confirmPermission}
                  className="w-full py-6 bg-purple-600 text-white rounded-[2rem] font-black uppercase tracking-widest italic flex items-center justify-center gap-3 shadow-[0_15px_40px_rgba(124,58,237,0.4)] active:scale-95 transition-all"
                >
                  <ShieldCheck className="w-6 h-6" />
                  Confirm
                </button>
                <button
                  onClick={denyPermission}
                  className="w-full py-6 bg-zinc-900 text-zinc-500 rounded-[2rem] font-bold uppercase tracking-widest hover:bg-zinc-800 transition-all"
                >
                  Abort
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      <div className="text-center space-y-3">
        <h2 className="text-3xl font-black text-white italic tracking-tighter uppercase">Visual Ingest</h2>
        <p className="text-zinc-500 text-[10px] font-bold uppercase tracking-[0.3em]">Neural forensic media verification hub</p>
      </div>

      <div className="space-y-8">
        {!previewUrl ? (
          <label className="block w-full">
            <div className="w-full aspect-[4/3] rounded-[3.5rem] bg-zinc-950 border border-white/5 flex flex-col items-center justify-center gap-8 hover:bg-zinc-900/50 hover:border-purple-500/30 transition-all cursor-pointer group shadow-2xl relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-b from-purple-600/5 to-transparent"></div>
              <div className="w-24 h-24 bg-zinc-900 rounded-[2.5rem] flex items-center justify-center border border-white/5 text-zinc-700 group-hover:text-purple-500 transition-all group-hover:scale-110 shadow-inner relative z-10">
                <ImageIcon className="w-12 h-12" />
              </div>
              <div className="text-center px-10 relative z-10">
                <p className="text-xs font-black text-zinc-400 uppercase tracking-widest mb-2 group-hover:text-zinc-200">Import Target</p>
                <p className="text-[9px] text-zinc-700 font-bold uppercase tracking-tighter italic">Photo or Motion Data Fragments</p>
              </div>
            </div>
            <input type="file" accept="image/*,video/*" onChange={handleFileChange} className="hidden" />
          </label>
        ) : (
          <div className="space-y-8 animate-in slide-up">
            <div className="relative w-full aspect-[4/3] rounded-[3.5rem] overflow-hidden border border-white/5 bg-black group shadow-2xl purple-glow">
              {mediaType === AnalysisType.IMAGE ? (
                <img src={previewUrl} alt="Preview" className="w-full h-full object-contain" />
              ) : (
                <video src={previewUrl} className="w-full h-full object-contain" controls />
              )}
              
              {/* Scan Overlay Effect */}
              {isAnalyzing && (
                <div className="absolute inset-0 pointer-events-none">
                  <div className="scan-line"></div>
                </div>
              )}

              <button 
                onClick={() => {
                  setMediaFile(null);
                  setPreviewUrl(null);
                }}
                className="absolute top-6 right-6 p-3 bg-black/60 backdrop-blur-xl rounded-2xl text-zinc-400 hover:text-purple-500 transition-colors border border-white/5 shadow-2xl"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <button
              onClick={handleAnalyze}
              disabled={isAnalyzing}
              className="w-full py-8 bg-purple-600 text-white rounded-[2.5rem] font-black text-lg uppercase tracking-[0.3em] italic flex items-center justify-center gap-5 shadow-[0_20px_60px_rgba(124,58,237,0.4)] hover:bg-purple-700 active:scale-[0.98] transition-all pulse-purple"
            >
              {isAnalyzing ? (
                <>
                  <Loader2 className="w-8 h-8 animate-spin" />
                  Tracing Pixels...
                </>
              ) : (
                <>
                  <Eye className="w-8 h-8" />
                  Initiate Audit
                </>
              )}
            </button>
          </div>
        )}

        {isAnalyzing && (
          <div className="text-center space-y-6 animate-in fade-in">
             <div className="w-full h-1.5 bg-zinc-900 rounded-full overflow-hidden p-0.5 border border-white/5">
                <div className="h-full bg-purple-600 animate-[progress_1.5s_infinite] rounded-full shadow-[0_0_10px_#a855f7]" />
             </div>
             <p className="text-[9px] font-bold text-zinc-500 uppercase tracking-[0.4em] italic">Scanning Spectral Inconsistencies & Jitter Artifacts</p>
          </div>
        )}

        {error && (
          <div className="p-6 bg-red-950/10 border border-red-900/20 rounded-[2.5rem] flex items-start gap-5 text-red-500 text-[10px] font-black uppercase tracking-widest leading-relaxed">
            <AlertCircle className="w-5 h-5 shrink-0 mt-0.5" />
            <p>{error}</p>
          </div>
        )}

        <div className="p-8 bg-zinc-900/30 rounded-[3rem] border border-white/5 space-y-4 relative overflow-hidden group">
          <div className="absolute inset-0 bg-gradient-to-br from-purple-600/5 to-transparent opacity-50"></div>
          <div className="flex items-center gap-3 relative z-10">
             <Zap className="w-4 h-4 text-purple-600" />
             <h4 className="text-[10px] font-black text-zinc-400 uppercase tracking-widest">Neural Forensic Engine v4.5</h4>
          </div>
          <p className="text-[11px] text-zinc-600 leading-relaxed font-bold uppercase tracking-widest italic relative z-10">
            ShieldX performs frame-by-frame muscle jitter verification, lighting gradient audit, and frequency domain anomaly detection to distinguish between authentic and synthetic data streams.
          </p>
        </div>
      </div>
      
      <style>{`
        @keyframes progress {
          0% { width: 0; margin-left: 0; }
          50% { width: 50%; margin-left: 25%; }
          100% { width: 0; margin-left: 100%; }
        }
      `}</style>
    </div>
  );
};

export default MediaScanner;
