
import React, { useState } from 'react';
import { Shield, Phone, Loader2, Lock, ArrowRight, Zap, Fingerprint } from 'lucide-react';

interface LoginProps {
  onLogin: (phoneNumber: string) => void;
}

const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const [phoneNumber, setPhoneNumber] = useState('');
  const [isAuthenticating, setIsAuthenticating] = useState(false);

  const handleInitialize = (e: React.FormEvent) => {
    e.preventDefault();
    if (phoneNumber.length < 8) return;
    setIsAuthenticating(true);
    
    setTimeout(() => {
      setIsAuthenticating(false);
      onLogin(phoneNumber);
    }, 2500);
  };

  return (
    <div className="min-h-screen bg-black flex flex-col items-center justify-center p-8 relative overflow-hidden">
      {/* Background Ambience */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-purple-600/10 rounded-full blur-[120px]"></div>
        <div className="absolute bottom-[-100px] left-[-100px] w-[500px] h-[500px] bg-indigo-600/5 rounded-full blur-[120px]"></div>
        {/* Subtle grid pattern overlay */}
        <div className="absolute inset-0 opacity-[0.03] bg-[linear-gradient(to_right,#808080_1px,transparent_1px),linear-gradient(to_bottom,#808080_1px,transparent_1px)] bg-[size:40px_40px]"></div>
      </div>

      <div className="w-full max-w-sm space-y-12 relative z-10 slide-up">
        {/* Branding */}
        <div className="text-center space-y-6">
          <div className="inline-flex p-6 rounded-[2.5rem] bg-zinc-950 border border-purple-500/20 shadow-[0_0_50px_rgba(168,85,247,0.1)] mb-2 relative group overflow-hidden">
            <Zap className="w-16 h-16 text-purple-500 fill-current group-hover:scale-110 transition-transform duration-500 relative z-10" />
            <div className="absolute inset-0 bg-gradient-to-br from-purple-600/10 to-transparent"></div>
            <div className="absolute inset-0 border border-purple-500/10 animate-pulse"></div>
          </div>
          <div className="space-y-2">
            <h1 className="text-5xl font-black tracking-tighter text-white italic uppercase">
              SHIELD<span className="text-purple-500">X</span> PRO
            </h1>
            <p className="text-purple-300/40 text-[10px] font-bold uppercase tracking-[0.6em]">Neural Defense Interface</p>
          </div>
        </div>

        {/* Auth Interface */}
        <div className="bg-zinc-900/40 backdrop-blur-3xl p-10 rounded-[3rem] border border-white/5 shadow-2xl space-y-8 relative overflow-hidden">
          <div className="space-y-3 relative z-10">
            <h2 className="text-xl font-bold text-white italic tracking-tight uppercase">Terminal Sync</h2>
            <p className="text-[11px] text-zinc-500 font-bold uppercase tracking-widest leading-relaxed">
              Operator must verify terminal identity to establish a secure link.
            </p>
          </div>

          <form onSubmit={handleInitialize} className="space-y-6 relative z-10">
            <div className="relative group">
              <div className="absolute inset-y-0 left-6 flex items-center pointer-events-none">
                <Phone className="w-5 h-5 text-zinc-700 group-focus-within:text-purple-500 transition-colors" />
              </div>
              <input
                type="tel"
                required
                value={phoneNumber}
                onChange={(e) => setPhoneNumber(e.target.value)}
                placeholder="+1 000 000 000"
                className="w-full pl-16 pr-6 py-6 bg-black/50 border border-white/5 rounded-3xl text-white placeholder:text-zinc-800 outline-none focus:border-purple-500/30 transition-all font-bold tracking-widest text-lg italic"
              />
            </div>

            <button
              type="submit"
              disabled={phoneNumber.length < 8 || isAuthenticating}
              className="w-full py-6 bg-purple-600 text-white rounded-3xl font-black uppercase tracking-[0.3em] italic flex items-center justify-center gap-4 shadow-[0_20px_50px_rgba(124,58,237,0.4)] hover:bg-purple-700 active:scale-[0.98] transition-all disabled:bg-zinc-900 disabled:text-zinc-700 disabled:shadow-none border border-purple-400/20"
            >
              {isAuthenticating ? (
                <>
                  <Loader2 className="w-6 h-6 animate-spin" />
                  Establishing Link...
                </>
              ) : (
                <>
                  Connect Sync
                  <ArrowRight className="w-5 h-5" />
                </>
              )}
            </button>
          </form>
          
          <div className="absolute bottom-0 right-0 p-8 opacity-5">
             <Fingerprint className="w-24 h-24 text-white" />
          </div>
        </div>

        {/* Status Indicator */}
        <div className="flex flex-col items-center gap-6">
          <div className="flex items-center gap-3 px-5 py-3 bg-zinc-900/50 rounded-full border border-white/5">
            <Lock className="w-3.5 h-3.5 text-purple-500" />
            <span className="text-[9px] font-bold text-zinc-500 uppercase tracking-[0.4em]">Encrypted Data Channel</span>
          </div>
          
          <div className="flex gap-2">
            <div className="w-1.5 h-1.5 rounded-full bg-purple-600 animate-pulse"></div>
            <div className="w-1.5 h-1.5 rounded-full bg-purple-600 animate-pulse [animation-delay:0.2s]"></div>
            <div className="w-1.5 h-1.5 rounded-full bg-purple-600 animate-pulse [animation-delay:0.4s]"></div>
          </div>
        </div>
      </div>

      <div className="absolute bottom-10 left-0 right-0 text-center">
        <p className="text-[7px] text-zinc-800 font-bold uppercase tracking-[0.8em]">CORE SYSTEM v4.5 // SHIELDX PROTOTYPE</p>
      </div>
    </div>
  );
};

export default Login;
