
import React, { useState, useRef } from 'react';
import { Mic, Upload, StopCircle, Play, Loader2, AlertCircle, Zap, Activity } from 'lucide-react';
import { analyzeContent } from '../services/geminiService';
import { AnalysisResult, AnalysisType } from '../types';
import ResultDisplay from '../components/ResultDisplay';

const VoiceScanner: React.FC = () => {
  const [isRecording, setIsRecording] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);

  const startRecording = async () => {
    try {
      setError(null);
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      chunksRef.current = [];

      mediaRecorder.ondataavailable = (e) => {
        if (e.data.size > 0) chunksRef.current.push(e.data);
      };

      mediaRecorder.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: 'audio/webm' });
        setAudioBlob(blob);
        stream.getTracks().forEach(track => track.stop());
      };

      mediaRecorder.start();
      setIsRecording(true);
    } catch (err) {
      console.error(err);
      setError("Authorization Revoked: Microphone access required for neural vocal capture.");
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setAudioBlob(file);
      setError(null);
    }
  };

  const runAnalysis = async () => {
    if (!audioBlob) return;
    setIsAnalyzing(true);
    setError(null);
    try {
      const analysis = await analyzeContent(
        audioBlob, 
        AnalysisType.VOICE, 
        audioBlob.type
      );
      setResult(analysis);
    } catch (err) {
      setError("Post-Call Analysis Failed: AI Core connection interrupted or neural buffer error.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  if (result) {
    return <ResultDisplay result={result} onReset={() => {
      setResult(null);
      setAudioBlob(null);
    }} />;
  }

  return (
    <div className="space-y-10 animate-in slide-up">
      <div className="text-center space-y-3">
        <h2 className="text-3xl font-black text-white italic tracking-tighter uppercase">Vocal Forensic</h2>
        <p className="text-zinc-500 text-[10px] font-bold uppercase tracking-[0.3em]">Neural capture of suspicious vocal patterns</p>
      </div>

      <div className="flex flex-col items-center gap-10">
        <div className="relative">
          {isRecording && (
            <div className="absolute -inset-16 bg-purple-600/20 rounded-full animate-ping [animation-duration:1.5s]"></div>
          )}
          <button
            onMouseDown={startRecording}
            onMouseUp={stopRecording}
            onTouchStart={startRecording}
            onTouchEnd={stopRecording}
            disabled={isAnalyzing}
            className={`w-48 h-48 rounded-full flex items-center justify-center transition-all shadow-2xl border-4 active:scale-95 relative z-10 group ${
              isRecording 
                ? 'bg-purple-600 border-purple-400 scale-110 shadow-[0_0_60px_rgba(168,85,247,0.5)]' 
                : 'bg-zinc-950 border-white/5 text-purple-600 hover:border-purple-500/30'
            } disabled:opacity-50`}
          >
            {isRecording ? (
              <StopCircle className="w-24 h-24 text-white" />
            ) : (
              <Mic className="w-24 h-24 group-hover:scale-110 transition-transform" />
            )}
            
            {/* Waveform indicator when recording */}
            {isRecording && (
              <div className="absolute bottom-6 flex gap-1 items-end h-8">
                 {[1,2,3,4,3,2,1].map((h, i) => (
                   <div key={i} className="w-1.5 bg-white rounded-full animate-[voice-bounce_0.6s_ease-in-out_infinite]" style={{ height: `${h * 25}%`, animationDelay: `${i * 0.1}s` }}></div>
                 ))}
              </div>
            )}
          </button>
        </div>

        <div className="w-full flex items-center gap-6">
          <div className="h-px bg-zinc-900 flex-1"></div>
          <span className="text-[9px] font-black text-zinc-700 uppercase tracking-[0.5em]">Manual Ingest</span>
          <div className="h-px bg-zinc-900 flex-1"></div>
        </div>

        <label className="w-full group">
          <div className="flex items-center justify-center gap-5 p-8 border border-white/5 rounded-[2.5rem] hover:bg-zinc-900/50 hover:border-purple-500/20 transition-all cursor-pointer bg-zinc-950 shadow-2xl relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-br from-purple-600/5 to-transparent"></div>
            <Upload className="w-7 h-7 text-zinc-600 group-hover:text-purple-600 transition-all group-hover:scale-110 relative z-10" />
            <span className="text-xs font-black text-zinc-500 uppercase tracking-widest group-hover:text-zinc-200 transition-colors relative z-10">Sync Audio Fragment</span>
          </div>
          <input type="file" accept="audio/*" onChange={handleFileUpload} className="hidden" />
        </label>
      </div>

      {audioBlob && !isAnalyzing && (
        <div className="bg-zinc-900/50 p-6 rounded-[2.5rem] border border-purple-500/20 flex items-center justify-between animate-in slide-up shadow-2xl relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-r from-purple-600/10 to-transparent"></div>
          <div className="flex items-center gap-5 relative z-10">
            <div className="w-14 h-14 bg-purple-600/20 rounded-2xl flex items-center justify-center text-purple-400 border border-purple-500/20 shadow-lg">
              <Play className="w-6 h-6 fill-current" />
            </div>
            <div>
              <p className="text-xs font-black text-white uppercase tracking-tight italic">Fragment Buffered</p>
              <p className="text-[10px] text-zinc-500 font-bold uppercase tracking-widest">Ready for Forensic Audit</p>
            </div>
          </div>
          <button
            onClick={runAnalysis}
            className="px-7 py-4 bg-purple-600 text-white rounded-[1.5rem] font-black text-[10px] uppercase tracking-widest shadow-xl shadow-purple-900/40 active:scale-95 transition-all relative z-10"
          >
            Run Audit
          </button>
        </div>
      )}

      {isAnalyzing && (
        <div className="text-center space-y-10 py-10 animate-in fade-in">
          <div className="relative inline-block">
            <div className="absolute inset-0 bg-purple-600 blur-[40px] opacity-20 animate-pulse"></div>
            <Loader2 className="w-20 h-20 text-purple-500 animate-spin mx-auto relative z-10" />
          </div>
          <div className="space-y-4">
            <h3 className="text-2xl font-black text-white italic uppercase tracking-tight">Neural Processing</h3>
            <p className="text-[10px] font-bold text-zinc-500 px-12 uppercase leading-relaxed tracking-[0.2em] italic">Cross-referencing vocal artifacts with known synthetic markers & breathing patterns...</p>
          </div>
        </div>
      )}

      {error && (
        <div className="p-6 bg-red-950/10 border border-red-900/20 rounded-[2.5rem] flex items-start gap-5 text-red-500 text-[10px] font-black uppercase tracking-widest leading-relaxed">
          <AlertCircle className="w-5 h-5 shrink-0 mt-0.5" />
          <p>{error}</p>
        </div>
      )}

      <div className="p-8 bg-zinc-900/30 rounded-[3rem] border border-white/5 space-y-5 relative overflow-hidden group">
        <div className="absolute inset-0 bg-gradient-to-br from-purple-600/5 to-transparent"></div>
        <h4 className="text-[10px] font-black text-purple-500 uppercase tracking-[0.4em] flex items-center gap-3 relative z-10">
          <Activity className="w-4 h-4" />
          Vocal Spectrum Hub
        </h4>
        <p className="text-[11px] text-zinc-600 leading-relaxed font-bold uppercase tracking-widest italic relative z-10">
          ShieldX audits audio fragments for breathing cadence, mouth click consistency, and AI-generated spectral anomalies characteristic of deepfake vocal clones.
        </p>
      </div>

      <style>{`
        @keyframes voice-bounce {
          0%, 100% { transform: scaleY(1); }
          50% { transform: scaleY(2); }
        }
      `}</style>
    </div>
  );
};

export default VoiceScanner;
